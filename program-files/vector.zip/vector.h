#ifndef OOP_ASSIGNMENTS_VECTOR_VECTOR_H_
#define OOP_ASSIGNMENTS_VECTOR_VECTOR_H_
#define VECTOR_MEMORY_IMPLEMENTED

#include <memory>
#include <iterator>
#include <stdexcept>
#include <exception>
#include <algorithm>

template <typename T, class Allocator = std::allocator<T>>
class Vector {
 public:
  using ValueType = T;
  using Pointer = T *;
  using ConstPointer = const T *;
  using Reference = T &;
  using ConstReference = const T &;
  using SizeType = size_t;
  using Iterator = Pointer;
  using ConstIterator = ConstPointer;
  using ReverseIterator = std::reverse_iterator<Iterator>;
  using ConstReverseIterator = std::reverse_iterator<ConstIterator>;

 private:
  using AllocTraits = std::allocator_traits<Allocator>;
  template <class Iter>
  using EnableIfForwardIter = std::enable_if_t<
      std::is_base_of_v<std::forward_iterator_tag, typename std::iterator_traits<Iter>::iterator_category>>;

 public:
  template <typename MoveIterator>
  void MoveWithTwoIter(MoveIterator begin, MoveIterator end) {
    std::move_iterator<MoveIterator> mbegin(begin);
    std::move_iterator<MoveIterator> mend(end);
    CopyWithTwoIter(mbegin, mend);
  }

  template <typename CopyIterator>
  void CopyWithTwoIter(CopyIterator begin, CopyIterator end) {
    size_t check_size = 0;
    auto iter = begin;
    try {
      for (; iter != end; ++iter) {
        AllocTraits::construct(alloc_, buffer_ + check_size, *iter);
        ++check_size;
      }
    } catch (...) {
      for (int64_t i = check_size - 1; i >= 0; --i) {
        AllocTraits::destroy(alloc_, buffer_ + i);
      }
      throw;
    }
  }

  template <typename MoveIterator>
  void MoveIterToNewPlace(MoveIterator begin, MoveIterator end, Pointer buffer) {
    auto check_size = 0;
    std::move_iterator<MoveIterator> mbegin(begin);
    std::move_iterator<MoveIterator> mend(end);
    auto iter = mbegin;
    try {
      for (; iter != mend; ++iter) {
        AllocTraits::construct(alloc_, buffer + check_size, *iter);
        ++check_size;
      }
    } catch (...) {
      throw;
    }
  }

  Vector() noexcept = default;

  Vector(const std::initializer_list<T> &container) {
    try {
      capacity_ = size_;
      size_ = container.size();
      if (container.size() != 0) {
        buffer_ = AllocTraits::allocate(alloc_, capacity_);
        CopyWithTwoIter(container.begin(), container.end());
      }
    } catch (...) {
      AllocTraits::deallocate(alloc_, buffer_, capacity_);
      size_ = 0;
      capacity_ = 0;
      buffer_ = nullptr;
      throw;
    }
  }

  Vector(std::initializer_list<T> &&container) {
    try {
      size_ = container.size();
      capacity_ = size_;
      if (container.size() != 0) {
        buffer_ = AllocTraits::allocate(alloc_, capacity_);
        MoveWithTwoIter(container.begin(), container.end());
      }
    } catch (...) {
      AllocTraits::deallocate(alloc_, buffer_, capacity_);
      size_ = 0;
      capacity_ = 0;
      buffer_ = nullptr;
      throw;
    }
  }

  template <typename Iterator, typename = EnableIfForwardIter<Iterator>>
  Vector(Iterator begin, Iterator end) {
    try {
      size_ = std::distance(begin, end);
      capacity_ = 2 * size_;
      if (size_ != 0) {
        buffer_ = AllocTraits::allocate(alloc_, capacity_);
        CopyWithTwoIter(begin, end);
      }
    } catch (...) {
      AllocTraits::deallocate(alloc_, buffer_, capacity_);
      size_ = 0;
      capacity_ = 0;
      buffer_ = nullptr;
      throw;
    }
  }

  Vector(const Vector &other) {
    try {
      alloc_ = other.alloc_;
      size_ = other.size_;
      capacity_ = other.capacity_;
      if (size_ != 0) {
        buffer_ = AllocTraits::allocate(alloc_, capacity_);
        CopyWithTwoIter(other.begin(), other.end());
      }
    } catch (...) {
      AllocTraits::deallocate(alloc_, buffer_, capacity_);
      size_ = 0;
      capacity_ = 0;
      buffer_ = nullptr;
      throw;
    }
  }

  Vector(Vector &&other) noexcept {
    alloc_ = other.alloc_;
    buffer_ = std::exchange(other.buffer_, nullptr);
    size_ = std::exchange(other.size_, 0);
    capacity_ = std::exchange(other.capacity_, 0);
  }

  void SefLyAllocate(const ValueType &value) {
    size_t count = 0;
    try {
      buffer_ = AllocTraits::allocate(alloc_, capacity_);
      for (auto iter = begin(); iter != end(); ++iter) {
        AllocTraits::construct(alloc_, iter, value);
        ++count;
      }
    } catch (...) {
      for (size_t i = 0; i < count; i++) {
        AllocTraits::destroy(alloc_, buffer_ + i);
      }
      AllocTraits::deallocate(alloc_, buffer_, capacity_);
      size_ = 0;
      capacity_ = 0;
      buffer_ = nullptr;
      throw;
    }
  }

  explicit Vector(size_t cnt) {
    capacity_ = cnt;
    size_ = cnt;
    if (cnt != 0) {
      SefLyAllocate();
    }
  }

  Vector(size_t cnt, const T &value) {
    size_ = cnt;
    capacity_ = cnt;
    if (cnt != 0) {
      SefLyAllocate(value);
    }
  }

  Vector &operator=(const Vector &other) {
    if (this != &other) {
      auto backup_buff = std::exchange(buffer_, nullptr);
      auto backup_size = std::exchange(size_, 0);
      auto backup_capacity = std::exchange(capacity_, 0);
      try {
        Vector(other).Swap(*this);
        for (size_t i = 0; i < backup_size; i++) {
          AllocTraits::destroy(alloc_, backup_buff + i);
        }
        AllocTraits::deallocate(alloc_, backup_buff, backup_capacity);
      } catch (...) {
        buffer_ = backup_buff;
        size_ = backup_size;
        capacity_ = backup_capacity;
        throw;
      }
    }
    return *this;
  }

  Vector &operator=(Vector &&other) noexcept {
    if (this != &other) {
      Vector(std::move(other)).Swap(*this);
    }
    return *this;
  }

  void DestroyDeallocate(size_t begin, size_t end, Pointer &buffer, size_t capacity) {
    for (size_t i = begin; i < end; i++) {
      AllocTraits::destroy(alloc_, buffer + i);
    }
    AllocTraits::deallocate(alloc_, buffer, capacity);
  }

  ~Vector() noexcept(std::is_nothrow_destructible_v<ValueType>) {
    DestroyDeallocate(0, size_, buffer_, capacity_);
  }

  [[nodiscard]] SizeType Size() const noexcept {
    return size_;
  }

  [[nodiscard]] SizeType Capacity() const noexcept {
    return capacity_;
  }

  [[nodiscard]] bool Empty() const noexcept {
    return size_ == 0;
  }

  [[nodiscard]] ConstReference Front() const noexcept {
    return buffer_[0];
  }

  [[nodiscard]] Reference Front() noexcept {
    return const_cast<Reference>(const_cast<const Vector &>(*this).Front());
  }

  [[nodiscard]] ConstReference Back() const noexcept {
    return buffer_[size_ - 1];
  }

  [[nodiscard]] Reference Back() noexcept {
    return const_cast<Reference>(const_cast<const Vector &>(*this).Back());
  }

  [[nodiscard]] ConstReference At(size_t idx) const {
    if (idx >= size_) {
      throw std::out_of_range("");
    }
    return (*this)[idx];
  }

  [[nodiscard]] Reference At(size_t idx) {
    return const_cast<Reference>(const_cast<const Vector &>(*this).At(idx));
  }

  [[nodiscard]] ConstPointer Data() const noexcept {
    return buffer_;
  }

  [[nodiscard]] Pointer Data() noexcept {
    return const_cast<Pointer>(const_cast<const Vector &>(*this).Data());
  }

  [[nodiscard]] ConstReference operator[](size_t idx) const noexcept {
    return buffer_[idx];
  }

  [[nodiscard]] Reference operator[](size_t idx) noexcept {
    return const_cast<Reference>(const_cast<const Vector &>(*this)[idx]);
  }

  void Swap(Vector &other) noexcept {
    std::swap(buffer_, other.buffer_);
    std::swap(size_, other.size_);
    std::swap(capacity_, other.capacity_);
    std::swap(alloc_, other.alloc_);
  }

  void Destroy(size_t begin, size_t end) {
    for (size_t i = begin; i < end; i++) {
      AllocTraits::destroy(alloc_, buffer_ + i);
    }
    size_ = begin;
  }

  void Clear() noexcept(std::is_nothrow_destructible_v<ValueType>) {
    Destroy(0, size_);
  }

  void ConstructSafely(size_t begin, size_t end, Pointer &buffer) {
    size_t count = 0;
    auto backup_size = size_;
    try {
      for (size_t i = begin; i < end; ++i) {
        AllocTraits::construct(alloc_, buffer + i);
        ++count;
      }
      size_ = size_ - begin + end;
    } catch (...) {
      size_ = backup_size;
      for (size_t i = begin; i < begin + count; i++) {
        AllocTraits::destroy(alloc_, buffer + i);
      }
      throw;
    }
  }

  void ConstructSafely(size_t begin, size_t end, Pointer &buffer, const ValueType &value) {
    size_t count = 0;
    auto backup_size = size_;
    try {
      for (size_t i = begin; i < end; ++i) {
        AllocTraits::construct(alloc_, buffer + i, value);
        ++count;
      }
      size_ = size_ - begin + end;
    } catch (...) {
      size_ = backup_size;
      for (size_t i = begin; i < begin + count; i++) {
        AllocTraits::destroy(alloc_, buffer + i);
      }
      throw;
    }
  }

  void SefLyAllocate() {
    size_t count = 0;
    try {
      buffer_ = AllocTraits::allocate(alloc_, capacity_);
      for (auto iter = begin(); iter != end(); ++iter) {
        AllocTraits::construct(alloc_, iter);
        ++count;
      }
    } catch (...) {
      for (size_t i = 0; i < count; i++) {
        AllocTraits::destroy(alloc_, buffer_ + i);
      }
      AllocTraits::deallocate(alloc_, buffer_, capacity_);
      size_ = 0;
      capacity_ = 0;
      buffer_ = nullptr;
      throw;
    }
  }

  Pointer SefLyAllocate(size_t size) {
    size_t count = 0;
    auto backup_buff = buffer_;
    auto backup_size = size_;
    auto backup_capacity = capacity_;
    auto new_buff = AllocTraits::allocate(alloc_, size * 2);
    try {
      for (size_t i = size_; i < size; ++i) {
        AllocTraits::construct(alloc_, new_buff + i);
        ++count;
      }
    } catch (...) {
      for (size_t i = size_; i < size_ + count; ++i) {
        AllocTraits::destroy(alloc_, new_buff + i);
      }
      AllocTraits::deallocate(alloc_, new_buff, size * 2);
      capacity_ = backup_capacity;
      size_ = backup_size;
      buffer_ = backup_buff;
      throw;
    }
    return new_buff;
  }

  Pointer SefLyAllocate(size_t size, const ValueType &value) {
    size_t count = 0;
    auto backup_buff = buffer_;
    auto backup_size = size_;
    auto backup_capacity = capacity_;
    auto new_buff = AllocTraits::allocate(alloc_, size * 2);
    try {
      for (size_t i = size_; i < size; ++i) {
        AllocTraits::construct(alloc_, new_buff + i, value);
        ++count;
      }
    } catch (...) {
      for (size_t i = size_; i < size_ + count; ++i) {
        AllocTraits::destroy(alloc_, new_buff + i);
      }
      AllocTraits::deallocate(alloc_, new_buff, size * 2);
      capacity_ = backup_capacity;
      size_ = backup_size;
      buffer_ = backup_buff;
      throw;
    }
    return new_buff;
  }

  void Resize(size_t size) {
    if (size != size_) {
      if (size < size_) {
        Destroy(size, size_);
        return;
      }
      if (size <= capacity_) {
        ConstructSafely(size_, size, buffer_);
        return;
      }
      if (size > capacity_) {
        auto new_buff = SefLyAllocate(size);
        MoveIterToNewPlace(begin(), end(), new_buff);
        DestroyDeallocate(0, size_, buffer_, capacity_);
        capacity_ = size * 2;
        buffer_ = new_buff;
        size_ = size;
      }
    }
  }

  void Resize(size_t size, const T &value) {
    if (size != size_) {
      if (size < size_) {
        Destroy(size, size_);
        return;
      }
      if (size <= capacity_) {
        ConstructSafely(size_, size, buffer_, value);
        return;
      }
      if (size > capacity_) {
        auto new_buff = SefLyAllocate(size, value);
        MoveIterToNewPlace(begin(), end(), new_buff);
        DestroyDeallocate(0, size_, buffer_, capacity_);
        capacity_ = size * 2;
        buffer_ = new_buff;
        size_ = size;
      }
    }
  }

  void Reserve(size_t capacity) {
    if (capacity_ < capacity) {
      auto backup_buff = buffer_;
      auto backup_capacity = capacity_;
      try {
        auto new_buff = AllocTraits::allocate(alloc_, capacity);
        MoveIterToNewPlace(begin(), end(), new_buff);
        DestroyDeallocate(0, size_, buffer_, capacity_);
        capacity_ = capacity;
        buffer_ = new_buff;
      } catch (...) {
        capacity_ = backup_capacity;
        buffer_ = backup_buff;
        throw;
      }
    }
  }

  void ShrinkToFit() {
    auto backup_buff = buffer_;
    auto backup_size = size_;
    auto backup_capacity = capacity_;
    try {
      if (size_ == 0) {
        AllocTraits::deallocate(alloc_, buffer_, capacity_);
        buffer_ = nullptr;
      } else {
        auto new_buff = AllocTraits::allocate(alloc_, size_);
        MoveIterToNewPlace(begin(), end(), new_buff);
        DestroyDeallocate(0, size_, buffer_, capacity_);
        buffer_ = new_buff;
      }
      capacity_ = size_;
    } catch (...) {
      capacity_ = backup_capacity;
      size_ = backup_size;
      buffer_ = backup_buff;
      throw;
    }
  }

  template <class... Args>
  void EmplaceBack(Args &&... args) {
    if (size_ < capacity_) {
      try {
        AllocTraits::construct(alloc_, end(), std::forward<Args>(args)...);
      } catch (...) {
        AllocTraits::destroy(alloc_, end());
        throw;
      }
      ++size_;
    } else {
      auto backup_buff = buffer_;
      auto backup_size = size_;
      auto backup_capacity = capacity_;
      if (capacity_ == 0) {
        buffer_ = AllocTraits::allocate(alloc_, 1);
        try {
          AllocTraits::construct(alloc_, end(), std::forward<Args>(args)...);
          capacity_ = 1;
          ++size_;
        } catch (...) {
          size_ = backup_size;
          capacity_ = backup_capacity;
          buffer_ = backup_buff;
          DestroyDeallocate(size_, size_ + 1, buffer_, 1);
          throw;
        }
      } else {
        auto new_buff = AllocTraits::allocate(alloc_, capacity_ * 2);
        try {
          AllocTraits::construct(alloc_, new_buff + size_, std::forward<Args>(args)...);
          MoveIterToNewPlace(begin(), end(), new_buff);
          for (size_t i = 0; i < size_; i++) {
            AllocTraits::destroy(alloc_, buffer_ + i);
          }
          AllocTraits::deallocate(alloc_, buffer_, capacity_);
          buffer_ = new_buff;
          capacity_ = capacity_ * 2;
          ++size_;
        } catch (...) {
          size_ = backup_size;
          capacity_ = backup_capacity;
          buffer_ = backup_buff;
          DestroyDeallocate(size_, size_ + 1, new_buff, capacity_ * 2);
          throw;
        }
      }
    }
  }

  void PushBack(const T &value) {
    EmplaceBack(value);
  }

  void PushBack(T &&value) {
    EmplaceBack(std::move(value));
  }

  void PopBack() noexcept(std::is_nothrow_destructible_v<ValueType>) {
    if (!Empty()) {
      --size_;
      AllocTraits::destroy(alloc_, end());
    }
  }

  [[nodiscard]] ConstIterator cbegin() const noexcept {  // NOLINT
    return Data();
  }

  [[nodiscard]] ConstIterator begin() const noexcept {  // NOLINT
    return cbegin();
  }

  [[nodiscard]] Iterator begin() noexcept {  // NOLINT
    return Data();
  }

  [[nodiscard]] ConstIterator cend() const noexcept {  // NOLINT
    return Data() + size_;
  }

  [[nodiscard]] ConstIterator end() const noexcept {  // NOLINT
    return cend();
  }

  [[nodiscard]] Iterator end() noexcept {  // NOLINT
    return Data() + size_;
  }

  [[nodiscard]] ConstReverseIterator crbegin() const noexcept {  // NOLINT
    return ConstReverseIterator(cend());
  }

  [[nodiscard]] ConstReverseIterator rbegin() const noexcept {  // NOLINT
    return crbegin();
  }

  [[nodiscard]] ReverseIterator rbegin() noexcept {  // NOLINT
    return ReverseIterator(end());
  }

  [[nodiscard]] ConstReverseIterator crend() const noexcept {  // NOLINT
    return ConstReverseIterator(cbegin());
  }

  [[nodiscard]] ConstReverseIterator rend() const noexcept {  // NOLINT
    return crend();
  }

  [[nodiscard]] ReverseIterator rend() noexcept {  // NOLINT
    return ReverseIterator(begin());
  }

  template <typename Type, class Alloc>
  friend bool operator==(const Vector<Type, Alloc> &left, const Vector<Type, Alloc> &right) noexcept;

  template <typename Type, class Alloc>
  friend bool operator<(const Vector<Type, Alloc> &left, const Vector<Type, Alloc> &right) noexcept;

 private:
  Allocator alloc_{Allocator{}};
  T *buffer_{nullptr};
  size_t size_{0};
  size_t capacity_{0};
};

template <typename T, class Allocator>
[[nodiscard]] bool operator==(const Vector<T, Allocator> &left, const Vector<T, Allocator> &right) noexcept {
  if (left.Size() == right.Size()) {
    for (size_t i = 0; i < left.Size(); ++i) {
      if (left[i] != right[i]) {
        return false;
      }
    }
    return true;
  }
  return false;
}

template <typename T, class Allocator>
[[nodiscard]] bool operator<(const Vector<T, Allocator> &left, const Vector<T, Allocator> &right) noexcept {
  return std::lexicographical_compare(left.begin(), left.end(), right.begin(), right.end());
}

template <typename T, class Allocator>
[[nodiscard]] bool operator!=(const Vector<T, Allocator> &left, const Vector<T, Allocator> &right) noexcept {
  return !(left == right);
}

template <typename T, class Allocator>
[[nodiscard]] bool operator>(const Vector<T, Allocator> &left, const Vector<T, Allocator> &right) noexcept {
  return right < left;
}

template <typename T, class Allocator>
[[nodiscard]] bool operator<=(const Vector<T, Allocator> &left, const Vector<T, Allocator> &right) noexcept {
  return !(left > right);
}

template <typename T, class Allocator>
[[nodiscard]] bool operator>=(const Vector<T, Allocator> &left, const Vector<T, Allocator> &right) noexcept {
  return !(left < right);
}

#endif  // OOP_ASSIGNMENTS_VECTOR_VECTOR_H_