#include "big_integer.h"

BigInteger BigInteger::operator-() const {
  BigInteger result = *this;
  if (sign_ == '+') {
    result.sign_ = '-';
    return result;
  }
  result.sign_ = '+';
  return result;
}

BigInteger &BigInteger::operator-=(const BigInteger &other) {
  if (other.sign_ == '-' && sign_ == '-') {
    ChangeSign();
    other.ChangeSign();
    *this = *this - other;
    other.ChangeSign();
    ChangeSign();
    return *this;
  }
  if (other.sign_ == '-' && sign_ == '+') {
    other.ChangeSign();
    *this = other + *this;
    other.ChangeSign();
    return *this;
  }
  if (other.sign_ == '+' && sign_ == '-') {
    ChangeSign();
    *this = other + *this;
    ChangeSign();
    return *this;
  }
  BigInteger result;
  int min_size = 0;
  int max_size = 0;
  const BigInteger *min = this;
  const BigInteger *max = &other;
  if (*this < other) {
    min_size = this->size_;
    max_size = other.size_;
    result.sign_ = '-';
  } else {
    max = this;
    min = &other;
    max_size = this->size_;
    min_size = other.size_;
  }
  result.size_ = max_size;
  int64_t a = 0;
  for (int i = 0; i < min_size; ++i) {
    a = (result.key_[i] + max->key_[i] - min->key_[i]);
    if (a < 0) {
      result.key_[i + 1] = -1;
      a = (100000000 + result.key_[i] + max->key_[i] - min->key_[i]) %
          100000000;
    }
    result.key_[i] = a;
  }
  for (int64_t i = min_size; i < max_size; ++i) {
    a = (result.key_[i] + max->key_[i]) % 100000000;
    if (a < 0) {
      result.key_[i + 1] = -1;
      a = (100000000 + result.key_[i] + max->key_[i]) % 100000000;
    }
    result.key_[i] = a;
  }
  result.DeleteNull();
  *this = result;
  return *this;
}

BigInteger &BigInteger::operator+=(const BigInteger &other) {
  if (other.sign_ == '-' && sign_ == '-') {
    ChangeSign();
    other.ChangeSign();
    *this = other + *this;
    other.ChangeSign();
    ChangeSign();
    return *this;
  }
  if (other.sign_ == '-' && sign_ == '+') {
    other.ChangeSign();
    *this = *this - other;
    other.ChangeSign();
    return *this;
  }
  if (other.sign_ == '+' && sign_ == '-') {
    ChangeSign();
    *this = *this - other;
    ChangeSign();
    return *this;
  }
  BigInteger result;
  const BigInteger *min = this;
  const BigInteger *max = &other;
  int min_size = 0;
  int max_size = 0;
  if (size_ < other.size_) {
    min_size = size_;
    max_size = other.size_;
  } else {
    min_size = other.size_;
    max_size = size_;
    max = this;
    min = &other;
  }
  result.size_ = max_size + 1;
  int64_t mul = 0;
  int64_t cur = 0;
  for (int i = 0; i < min_size; ++i) {
    mul = (result.key_[i] + max->key_[i] + min->key_[i]) % 100000000;
    cur = (result.key_[i] + max->key_[i] + min->key_[i]) / 100000000;
    result.key_[i] = mul;
    result.key_[i + 1] = cur;
  }
  for (int64_t i = min_size; i < max_size; ++i) {
    mul = (result.key_[i] + max->key_[i]) % 100000000;
    cur = (result.key_[i] + max->key_[i]) / 100000000;
    result.key_[i] = mul;
    result.key_[i + 1] = cur;
  }
  if (cur != 0) {
    mul = (result.key_[max_size]) % 100000000;
    result.key_[max_size] = mul;
    CheckSize();
    *this = result;
    return *this;
  }
  result.size_ = max_size;
  *this = result;
  return *this;
}

BigInteger &BigInteger::operator*=(const BigInteger &other) {
  BigInteger result;
  if (sign_ != other.sign_ && *this != 0 && other != 0) {
    result.sign_ = '-';
  }
  result.size_ = size_ + other.size_;
  if (result.size_ - 1 > 3750) {
    throw BigIntegerOverflow{};
  }
  for (int i = 0; i < size_; ++i) {
    for (int k = 0; k < other.size_; ++k) {
      int64_t mul = (result.key_[i + k] + key_[i] * other.key_[k]) / 100000000;
      result.key_[i + k] =
          (result.key_[i + k] + key_[i] * other.key_[k]) % 100000000;
      result.key_[i + k + 1] += mul;
    }
  }
  result.DeleteNull();
  result.CheckSize();
  *this = result;
  return *this;
}

BigInteger operator-(const BigInteger &left, const BigInteger &right) {
  BigInteger copy = left;
  copy -= right;
  return copy;
}

BigInteger operator+(const BigInteger &left, const BigInteger &right) {
  BigInteger copy = left;
  copy += right;
  return copy;
}

BigInteger operator*(const BigInteger &left, const BigInteger &right) {
  BigInteger result = left;
  result *= right;
  return result;
}

bool operator<(const BigInteger &left, const BigInteger &right) {
  if (left.size_ == right.size_ && left.sign_ == right.sign_) {
    int64_t i = left.size_ - 1;
    while (i >= 0) {
      if (left.key_[i] == right.key_[i]) {
        --i;
        continue;
      }
      if (left.key_[i] < right.key_[i]) {
        return (left.sign_ == '+');
      }
      if (left.key_[i] > right.key_[i]) {
        return (left.sign_ == '-');
      }
      return false;
    }
  }
  if (left.sign_ == right.sign_) {
    return left.size_ < right.size_;
  }
  return (left.sign_ == '-');
}

bool operator==(const BigInteger &left, const BigInteger &right) {
  return (!(left < right) && !(right < left));
}

bool operator!=(const BigInteger &left, const BigInteger &right) {
  return (left < right) || (right < left);
}

bool operator>(const BigInteger &left, const BigInteger &right) {
  return ((!(left < right) && (left < right)) || (right < left));
}

bool operator>=(const BigInteger &left, const BigInteger &right) {
  return (((!(left < right) && (left < right)) || (right < left)) ||
          (!(left < right) && !(right < left)));
}

bool operator<=(const BigInteger &left, const BigInteger &right) {
  return (left < right || (!(left < right) && !(right < left)));
}

std::istream &operator>>(std::istream &is, BigInteger &bigint) {
  std::string str;
  is >> str;
  int flag = 0;
  size_t cnt = str.length();
  bigint.size_ = static_cast<int>(cnt) / 8 + 1;
  if (str[0] == '+' || str[0] == '-') {
    flag = 1;
    --bigint.size_;
    if (str[0] == '-') {
      bigint.sign_ = '-';
    }
  }
  bigint.CheckSize();
  int k = 0;
  for (auto i = static_cast<int>(cnt); i > flag; i -= 8) {
    if (i < 8 + flag) {
      bigint.key_[k++] = atoi(str.substr(flag, i - flag).c_str());
      continue;
    }
    bigint.key_[k++] = atoi(str.substr(i - 8, 8).c_str());
  }
  bigint.size_ = k;
  bigint.CheckSize();
  return is;
}

std::ostream &operator<<(std::ostream &os, const BigInteger &bigint) {
  if (bigint.sign_ == '-') {
    os << '-';
  }
  os << bigint.key_[bigint.size_ - 1];
  char old_fill = os.fill('0');
  for (int i = bigint.size_ - 2; i >= 0; --i) {
    os << std::setw(8) << bigint.key_[i];
  }
  os.fill(old_fill);
  return os;
}
