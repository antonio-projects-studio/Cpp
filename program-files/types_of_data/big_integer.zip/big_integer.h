#ifndef BIG_INTEGER_H
#define BIG_INTEGER_H

#include <stdexcept>
#include <iostream>
#include <cstring>
#include <iomanip>

class BigIntegerOverflow : public std::runtime_error {
 public:
  BigIntegerOverflow() : std::runtime_error("BigIntegerOverflow") {
  }
};

class BigIntegerDivisionByZero : public std::runtime_error {
 public:
  BigIntegerDivisionByZero() : std::runtime_error("BigIntegerDivisionByZero") {
  }
};

class BigInteger {
 private:
  mutable char sign_ = '+';
  int size_ = 0;
  int64_t key_[3751]{};

 public:
  BigInteger() : sign_('+'), size_(0), key_(){};

  BigInteger(const BigInteger &other) = default;

  BigInteger &operator=(const BigInteger &other) = default;

  ~BigInteger() = default;

  template <class T>
  BigInteger(T cnt) : BigInteger() {  // NOLINT
    if (cnt < static_cast<T>(0)) {
      sign_ = '-';
      cnt = -cnt;
    }
    if (cnt == static_cast<T>(0)) {
      size_ = 1;
    }
    int64_t i = 0;
    int64_t mul = 0;
    while (cnt != 0) {
      mul = cnt % 100000000;
      cnt /= 100000000;
      key_[i++] = mul;
      ++size_;
    }
  }

  BigInteger(const char *c_str) : BigInteger() {  // NOLINT
    std::string str(c_str);
    size_t cnt = str.length();
    int flag = 0;
    size_ = static_cast<int>(cnt) / 8 + 1;
    if (str[0] == '+' || str[0] == '-') {
      --size_;
      flag = 1;
      if (str[0] == '-') {
        sign_ = '-';
      }
    }
    CheckSize();
    int k = 0;
    for (auto i = static_cast<int>(cnt); i > flag; i -= 8) {
      if (i < 8 + flag) {
        key_[k++] = atoi(str.substr(flag, i - flag).c_str());
        continue;
      }
      key_[k++] = atoi(str.substr(i - 8, 8).c_str());
    }
    size_ = k;
    CheckSize();
  }

  explicit operator bool() const {
    return *this != BigInteger(0);
  }

  void CheckSize() const {
    if (size_ > 3750) {
      throw BigIntegerOverflow{};
    }
  };

  void ChangeSign() const {
    if (*this == 0 || sign_ == '-') {
      sign_ = '+';
      return;
    }
    sign_ = '-';
  }

  void DeleteNull() {
    while (key_[size_ - 1] == 0 && size_ > 1) {
      --size_;
    }
  }

  bool IsNegative() {
    return sign_ == '-';
  }

  BigInteger operator-() const;

  BigInteger operator+() const {
    return *this;
  }

  BigInteger &operator--() {
    return *this -= 1;
  }

  BigInteger &operator++() {
    return *this += 1;
  }

  BigInteger operator--(int) {
    BigInteger copy = *this;
    *this -= 1;
    return copy;
  };

  BigInteger operator++(int) {
    BigInteger copy = *this;
    *this += 1;
    return copy;
  };

  BigInteger &operator*=(const BigInteger &other);

  BigInteger &operator+=(const BigInteger &other);

  BigInteger &operator-=(const BigInteger &other);

  friend BigInteger operator-(const BigInteger &left, const BigInteger &right);

  friend BigInteger operator+(const BigInteger &left, const BigInteger &right);

  friend BigInteger operator*(const BigInteger &left, const BigInteger &right);

  friend bool operator<(const BigInteger &left, const BigInteger &right);

  friend bool operator>(const BigInteger &left, const BigInteger &right);

  friend bool operator<=(const BigInteger &left, const BigInteger &right);

  friend bool operator>=(const BigInteger &left, const BigInteger &right);

  friend bool operator!=(const BigInteger &left, const BigInteger &right);

  friend bool operator==(const BigInteger &left, const BigInteger &right);

  friend std::istream &operator>>(std::istream &is, BigInteger &bigint);

  friend std::ostream &operator<<(std::ostream &os, const BigInteger &bigint);
};

#endif //BIG_INTEGER_H