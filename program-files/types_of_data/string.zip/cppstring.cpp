#include "cppstring.h"

void String::Swap(String& other) {
  String copy = *this;
  *this = other;
  other = copy;
}
String& String::operator+=(const String& other) {
  size_t size_copy = size_;
  size_ += other.size_;
  Allocate();
  for (size_t i = size_copy; i < size_; ++i) {
    str_[i] = other.str_[i - size_copy];
  }
  return *this;
}
void String::Resize(const size_t new_size, char symbol) {
  size_t size_copy = size_;
  size_ = new_size;
  if (new_size > size_copy) {
    Allocate();
  }
  for (size_t i = size_copy; i < size_; ++i) {
    str_[i] = symbol;
  }
}
void String::Reserve(const size_t new_capacity) {
  if (new_capacity > capacity_) {
    auto* str_new = new char[new_capacity];
    for (size_t i = 0; i < capacity_; ++i) {
      str_new[i] = str_[i];
    }
    capacity_ = new_capacity;
    delete[] str_;
    str_ = str_new;
  }
}
void String::ShrinkToFit() {
  capacity_ = size_;
  if (capacity_ != 0) {
    auto* str_new = new char[capacity_];
    for (size_t i = 0; i < size_; ++i) {
      str_new[i] = str_[i];
    }
    delete[] str_;
    str_ = str_new;
    return;
  }
  delete[] str_;
}
String operator+(const String& left, const String& right) {
  String copy = left;
  copy += right;
  return copy;
}
bool operator<(const String& left, const String& right) {
  size_t min_size = std::min(left.size_, right.size_);
  for (size_t i = 0; i < min_size; ++i) {
    if (left.str_[i] == right.str_[i]) {
      continue;
    }
    return left.str_[i] < right.str_[i];
  }
  return left.size_ < right.size_;
}
std::ostream& operator<<(std::ostream& os, const String& str) {
  for (size_t i = 0; i < str.size_; ++i) {
    os << str[i];
  }
  return os;
}
bool operator==(const String& left, const String& right) {
  return (!(left < right) && !(right < left));
}

bool operator!=(const String& left, const String& right) {
  return (left < right) || (right < left);
}

bool operator>(const String& left, const String& right) {
  return ((!(left < right) && (left < right)) || (right < left));
}

bool operator>=(const String& left, const String& right) {
  return (((!(left < right) && (left < right)) || (right < left)) || (!(left < right) && !(right < left)));
}

bool operator<=(const String& left, const String& right) {
  return (left < right || (!(left < right) && !(right < left)));
}