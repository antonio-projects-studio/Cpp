#ifndef CPPSTRING_H
#define CPPSTRING_H
#include <stdexcept>
#include <iostream>
#include <cstring>
class StringOutOfRange : public std::out_of_range {
 public:
  StringOutOfRange() : std::out_of_range("StringOutOfRange") {
  }
};

class String {
  size_t size_;
  size_t capacity_;
  char *str_;

 public:
  void Allocate() {
    if (size_ != 0 && capacity_ == 0) {
      capacity_ = size_;
      str_ = new char[capacity_];
      return;
    }
    if (size_ > capacity_) {
      size_t capacity_old = capacity_;
      while (size_ > capacity_) {
        capacity_ *= 2;
      }
      auto *str_new = new char[capacity_];
      for (size_t i = 0; i < capacity_old; ++i) {
        str_new[i] = str_[i];
      }
      delete[] str_;
      str_ = str_new;
    }
  }
  String() : size_(0), capacity_(0), str_(nullptr) {
  }
  String(size_t size, char symbol) : size_(size), capacity_(0), str_(nullptr) {
    Allocate();
    for (size_t i = 0; i < size_; ++i) {
      str_[i] = symbol;
    }
  }
  String(const char *array) : size_(0), capacity_(0), str_(nullptr) {  // NOLINT
    size_t size_array = strlen(array);
    size_ = size_array;
    Allocate();
    for (size_t i = 0; i < size_array; ++i) {
      str_[i] = array[i];
    }
  }
  String(const char *array, size_t size) : size_(size), capacity_(0), str_(nullptr) {
    Allocate();
    for (size_t i = 0; i < size; ++i) {
      str_[i] = array[i];
    }
  }
  String(const String &other) : size_(other.size_), capacity_(0), str_(nullptr) {
    Allocate();
    for (size_t i = 0; i < size_; ++i) {
      str_[i] = other.str_[i];
    }
  }
  ~String() {
    delete[] str_;
  }

  String &operator=(const String &other) {
    if (*this != other) {
      size_ = other.size_;
      Allocate();
      for (size_t i = 0; i < size_; ++i) {
        str_[i] = other.str_[i];
      }
      return *this;
    }
    return *this;
  }

  inline const char &operator[](size_t idx) const {
    return str_[idx];
  }

  inline char &operator[](size_t idx) {
    return const_cast<char &>(const_cast<const String &>(*this)[idx]);
  }

  inline const char &At(int64_t idx) const {
    if (static_cast<size_t>(idx) >= size_ || idx < 0) {
      throw StringOutOfRange{};
    }
    return str_[idx];
  }

  inline char &At(int64_t idx) {
    return const_cast<char &>(const_cast<const String &>(*this).At(idx));
  }

  inline const char &Front() const {
    return str_[0];
  }

  inline char &Front() {
    return const_cast<char &>(const_cast<const String &>(*this).Front());
  }

  inline const char &Back() const {
    return str_[size_ - 1];
  }

  inline char &Back() {
    return const_cast<char &>(const_cast<const String &>(*this).Back());
  }

  inline char *Data() {
    return str_;
  }

  inline const char *Data() const {
    return str_;
  }

  inline const char *CStr() const {
    return str_;
  }

  inline char *CStr() {
    return str_;
  }

  inline bool Empty() const {
    return size_ == 0;
  }

  inline size_t Size() const {
    return size_;
  }

  inline size_t Length() const {
    return size_;
  }

  inline size_t Capacity() const {
    return capacity_;
  }

  inline void Clear() {
    size_ = 0;
  }

  void Swap(String &other);

  inline void PopBack() {
    if (size_ > 0) {
      --size_;
    }
  }

  void PushBack(const char symbol) {
    ++size_;
    Allocate();
    str_[size_ - 1] = symbol;
  }

  String &operator+=(const String &other);

  void Resize(const size_t new_size, char symbol);

  void Reserve(const size_t new_capacity);

  void ShrinkToFit();

  friend String operator+(const String &left, const String &right);

  friend bool operator<(const String &left, const String &right);

  friend bool operator!=(const String &left, const String &right);

  friend std::ostream &operator<<(std::ostream &os, const String &str);
};

bool operator<=(const String &left, const String &right);
bool operator>(const String &left, const String &right);
bool operator>=(const String &left, const String &right);
bool operator==(const String &left, const String &right);

#endif //CPPSTRING_H