#pragma once

#include <utility>
#include <cstdint>

template <class Container>
class Object {
 private:
  Container &container_;

 public:
  using iterator = decltype(std::declval<Container>().rbegin());  // NOLINT
  using Type = decltype(*std::declval<iterator>());

  explicit Object(Container &container) : container_(container){};
  class Iterator {
    iterator iterator_;

   public:
    Iterator(const iterator iterator) : iterator_(iterator){};  // NOLINT
    Type operator*() {
      return *iterator_;
    }
    Iterator &operator++() {
      ++iterator_;
      return *this;
    }
    Iterator operator++(int) {
      auto copy = *this;
      ++iterator_;
      return copy;
    }
    auto operator-> () {
      return iterator_;
    }
    bool operator!=(const Iterator &other) {
      return iterator_ != other.iterator_;
    }
  };
  Iterator begin() const {  // NOLINT
    return {container_.rbegin()};
  }
  Iterator end() const {  // NOLINT
    return {container_.rend()};
  }
};

template <class Container>
auto Reversed(Container &&container) {
  return Object<decltype(container)>(container);
}