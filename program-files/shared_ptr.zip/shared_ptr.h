#pragma once
#define WEAK_PTR_IMPLEMENTED

#include <stdexcept>
#include <memory>
#include <iostream>

class BadWeakPtr : public std::runtime_error {
 public:
  BadWeakPtr() : std::runtime_error("BadWeakPtr") {
  }
};

template <class T, class Deleter = std::default_delete<T>>
class WeakPtr;

template <class T, class Deleter = std::default_delete<T>>
class SharedPtr;

struct ControlBlock {
  uint64_t ref_count_{0};
  uint64_t weak_count_{0};
};

template <class T, class Deleter>
class SharedPtr {
  Deleter deleter_{Deleter()};
  T *ptr_ = nullptr;
  ControlBlock *cnt_ = nullptr;

 public:
  SharedPtr() : ptr_(nullptr), cnt_(nullptr){};

  explicit SharedPtr(const WeakPtr<T> &other);

  SharedPtr(T *ptr) : ptr_(ptr) {  // NOLINT
    if (ptr_ != nullptr) {
      cnt_ = new ControlBlock;
      ++cnt_->ref_count_;
    }
  };

  SharedPtr(const SharedPtr &other) : ptr_(other.ptr_), cnt_(other.cnt_) {
    if (cnt_ != nullptr) {
      ++cnt_->ref_count_;
    }
  };

  SharedPtr &operator=(const SharedPtr &other) {
    if (this != &other) {
      if (ptr_ != nullptr) {
        --cnt_->ref_count_;
        if (cnt_->ref_count_ == 0) {
          deleter_(ptr_);
          if (cnt_->ref_count_ + cnt_->weak_count_ == 0) {
            delete cnt_;
          }
        }
      }
      ptr_ = other.ptr_;
      cnt_ = other.cnt_;
      if (cnt_ != nullptr) {
        ++cnt_->ref_count_;
      }
      return *this;
    }
    return *this;
  };

  SharedPtr(SharedPtr &&other) noexcept : ptr_(other.ptr_), cnt_(other.cnt_) {
    other.ptr_ = nullptr;
    other.cnt_ = nullptr;
  }

  SharedPtr &operator=(SharedPtr &&other) noexcept {
    if (this != &other) {
      if (ptr_ != nullptr) {
        --cnt_->ref_count_;
        if (cnt_->ref_count_ == 0) {
          deleter_(ptr_);
          if (cnt_->ref_count_ + cnt_->weak_count_ == 0) {
            delete cnt_;
          }
        }
      }
      ptr_ = other.ptr_;
      cnt_ = other.cnt_;
      other.ptr_ = nullptr;
      other.cnt_ = nullptr;
      return *this;
    }
    return *this;
  };

  T *Get() const noexcept {
    return ptr_;
  }

  ControlBlock *&CNT() {
    return cnt_;
  }

  ControlBlock *GetCnt() const {
    return cnt_;
  }

  T *&PTR() {
    return ptr_;
  }

  void Swap(SharedPtr &other) {
    T *copy = ptr_;
    ControlBlock *copy_2 = cnt_;
    ptr_ = other.ptr_;
    cnt_ = other.cnt_;
    other.ptr_ = copy;
    other.cnt_ = copy_2;
  }

  T &operator*() const {
    return *ptr_;
  }

  T *operator->() const {
    return ptr_;
  }

  void Reset(T *ptr = nullptr) {
    if (ptr_ != nullptr) {
      --cnt_->ref_count_;
      if (cnt_->ref_count_ == 0) {
        deleter_(ptr_);
        if (cnt_->ref_count_ + cnt_->weak_count_ == 0) {
          delete cnt_;
        }
      }
    }
    ptr_ = ptr;
    cnt_ = nullptr;
    if (ptr_ != nullptr) {
      cnt_ = new ControlBlock;
      ++cnt_->ref_count_;
    }
  }

  explicit operator bool() const {
    return ptr_ != nullptr;
  }

  size_t UseCount() const {
    if (cnt_ == nullptr) {
      return 0;
    }
    return cnt_->ref_count_;
  }

  ~SharedPtr() {
    if (ptr_ != nullptr) {
      --cnt_->ref_count_;
      if (cnt_->ref_count_ == 0) {
        deleter_(ptr_);
        if (cnt_->ref_count_ + cnt_->weak_count_ == 0) {
          delete cnt_;
          cnt_ = nullptr;
        }
        ptr_ = nullptr;
      }
    }
  }
};

template <class T, class Deleter>
class WeakPtr {
  T *ptr_ = nullptr;
  ControlBlock *cnt_ = nullptr;

 public:
  WeakPtr() : ptr_(nullptr), cnt_(nullptr){};

  WeakPtr(const WeakPtr &other) : ptr_(other.ptr_), cnt_(other.cnt_) {
    if (cnt_ != nullptr) {
      ++cnt_->weak_count_;
    }
  };

  WeakPtr(const SharedPtr<T> &other) {  // NOLINT
    ptr_ = other.Get();
    cnt_ = other.GetCnt();
    if (cnt_ != nullptr) {
      ++cnt_->weak_count_;
    }
  };

  WeakPtr &operator=(const WeakPtr &other) {
    if (this != &other) {
      if (cnt_ != nullptr) {
        --cnt_->weak_count_;
        if (cnt_->ref_count_ + cnt_->ref_count_ == 0) {
          delete cnt_;
        }
      }
      ptr_ = other.ptr_;
      cnt_ = other.cnt_;
      if (cnt_ != nullptr) {
        ++cnt_->weak_count_;
      }
      return *this;
    }
    return *this;
  };

  WeakPtr &operator=(const SharedPtr<T> &other) {
    if (cnt_ != nullptr) {
      --cnt_->weak_count_;

      if (cnt_->ref_count_ + cnt_->ref_count_ == 0) {
        delete cnt_;
      }
    }
    ptr_ = other.Get();
    cnt_ = other.GetCnt();
    if (cnt_ != nullptr) {
      ++cnt_->weak_count_;
    }
    return *this;
  };

  WeakPtr(WeakPtr &&other) noexcept : ptr_(other.ptr_), cnt_(other.cnt_) {
    other.ptr_ = nullptr;
    other.cnt_ = nullptr;
  }

  WeakPtr &operator=(WeakPtr &&other) noexcept {
    if (this != &other) {
      if (cnt_ != nullptr) {
        --cnt_->weak_count_;
        if (cnt_->weak_count_ + cnt_->ref_count_ == 0) {
          delete cnt_;
        }
      }
      ptr_ = other.ptr_;
      cnt_ = other.cnt_;
      other.ptr_ = nullptr;
      other.cnt_ = nullptr;
      return *this;
    }
    return *this;
  };

  T *PTR() const {
    return ptr_;
  }

  ControlBlock *CNT() const {
    return cnt_;
  }

  void Swap(WeakPtr &other) {
    T *copy = ptr_;
    ControlBlock *copy_2 = cnt_;
    ptr_ = other.ptr_;
    cnt_ = other.cnt_;
    other.ptr_ = copy;
    other.cnt_ = copy_2;
  }

  void Reset() {
    if (cnt_ != nullptr) {
      --cnt_->weak_count_;
      if (cnt_->ref_count_ + cnt_->weak_count_ == 0) {
        delete cnt_;
      }
    }
    cnt_ = nullptr;
    ptr_ = nullptr;
  }

  size_t UseCount() const {
    if (cnt_ == nullptr) {
      return 0;
    }
    return cnt_->ref_count_;
  }

  bool Expired() const {
    if (cnt_ == nullptr) {
      return true;
    }
    return cnt_->ref_count_ == 0;
  }

  SharedPtr<T> Lock() const {
    if (Expired()) {
      return nullptr;
    }
    SharedPtr<T> shared{};
    shared.PTR() = ptr_;
    shared.CNT() = cnt_;
    ++shared.CNT()->ref_count_;
    return shared;
  };

  ~WeakPtr() {
    if (cnt_ != nullptr) {
      --cnt_->weak_count_;
      if (cnt_->ref_count_ + cnt_->ref_count_ == 0) {
        delete cnt_;
        ptr_ = nullptr;
        cnt_ = nullptr;
      }
    }
  }
};

template <class T, class... Args>
SharedPtr<T> MakeShared(Args &&... args) {
  return SharedPtr<T>(new T(std::forward<Args>(args)...));
}

template <class T, class Deleter>
SharedPtr<T, Deleter>::SharedPtr(const WeakPtr<T> &other) {
  if (other.Expired()) {
    throw BadWeakPtr();
  }
  cnt_ = other.CNT();
  ptr_ = other.PTR();
  ++cnt_->ref_count_;
}
