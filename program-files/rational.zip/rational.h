#ifndef RATIONAL_H
#define RATIONAL_H

#include <stdexcept>
#include <algorithm>
#include <iostream>

class RationalDivisionByZero : public std::runtime_error {
 public:
  RationalDivisionByZero() : std::runtime_error("RationalDivisionByZero") {
  }
};

class Rational {
  int64_t numerator_;
  int64_t denominator_;

 public:
  Rational() : numerator_(0), denominator_(1) {
  }

  Rational(int64_t x, int64_t y) : numerator_(x), denominator_(y) {
    Reduction();
  }

  Rational(int64_t x) : numerator_(x) {  // NOLINT
    denominator_ = 1;
  }

  Rational(const Rational &) = default;

  ~Rational() = default;

  int64_t GetNumerator() const {
    return numerator_;
  }

  int64_t GetDenominator() const {
    return denominator_;
  }

  void Reduction();

  void SetNumerator(const int64_t &x);

  void SetDenominator(const int64_t &x);

  Rational &operator=(const Rational &other);

  Rational &operator+=(const Rational &other);

  Rational &operator-=(const Rational &other);

  Rational &operator*=(const Rational &other);

  Rational &operator/=(const Rational &other);

  friend Rational operator+(const Rational &left, const Rational &right);

  friend Rational operator-(const Rational &left, const Rational &right);

  Rational operator-() const;

  Rational operator+() const;

  friend Rational operator/(const Rational &left, const Rational &right);

  friend Rational operator*(const Rational &left, const Rational &right);

  Rational &operator++();

  Rational &operator--();

  Rational operator++(int);

  Rational operator--(int);

  friend bool operator<(const Rational &left, const Rational &other);

  friend bool operator>(const Rational &left, const Rational &other);

  friend bool operator==(const Rational &left, const Rational &other);

  friend bool operator<=(const Rational &left, const Rational &other);

  friend bool operator>=(const Rational &left, const Rational &other);

  friend bool operator!=(const Rational &left, const Rational &other);

  friend std::istream &operator>>(std::istream &is, Rational &rational);

  friend std::ostream &operator<<(std::ostream &os, const Rational &rational);
};

#endif //RATIONAL_H