#include "rational.h"

void Rational::Reduction() {
  if (denominator_ == 0) {
    throw RationalDivisionByZero{};
  }
  int64_t c = std::__gcd(numerator_, denominator_);
  numerator_ /= c;
  denominator_ /= c;
  if (denominator_ < 0) {
    numerator_ = -numerator_;
    denominator_ = -denominator_;
  }
}

void Rational::SetNumerator(const int64_t &x) {
  numerator_ = x;
  Reduction();
}

void Rational::SetDenominator(const int64_t &x) {
  denominator_ = x;
  Reduction();
}

Rational &Rational::operator+=(const Rational &other) {
  numerator_ = numerator_ * other.denominator_ + other.numerator_ * denominator_;
  denominator_ *= other.denominator_;
  Reduction();
  return *this;
}

Rational &Rational::operator=(const Rational &other) {
  if (*this != other) {
    numerator_ = other.numerator_;
    denominator_ = other.denominator_;
  }
  return *this;
}

Rational &Rational::operator-=(const Rational &other) {
  numerator_ = numerator_ * other.denominator_ - other.numerator_ * denominator_;
  denominator_ *= other.denominator_;
  Reduction();
  return *this;
}

Rational &Rational::operator*=(const Rational &other) {
  numerator_ *= other.numerator_;
  denominator_ *= other.denominator_;
  Reduction();
  return *this;
}

Rational &Rational::operator/=(const Rational &other) {
  numerator_ *= other.denominator_;
  denominator_ *= other.numerator_;
  Reduction();
  return *this;
}

Rational operator+(const Rational &left, const Rational &right) {
  auto ls = left;
  return ls += right;
}

Rational operator-(const Rational &left, const Rational &right) {
  auto ls = left;
  return ls -= right;
}

Rational operator*(const Rational &left, const Rational &right) {
  auto ls = left;
  return ls *= right;
}

Rational operator/(const Rational &left, const Rational &right) {
  auto ls = left;
  return ls /= right;
}

std::istream &operator>>(std::istream &is, Rational &rational) {
  is >> rational.numerator_;
  if (is.peek() == '/') {
    is.ignore(1);
    is >> rational.denominator_;
  } else {
    rational.denominator_ = 1;
  }
  rational.Reduction();
  return is;
}

std::ostream &operator<<(std::ostream &os, const Rational &rational) {
  if (rational.denominator_ != 1) {
    os << rational.numerator_ << '/' << rational.denominator_;
    return os;
  }
  os << rational.numerator_;
  return os;
}

Rational &Rational::operator++() {
  numerator_ += denominator_;
  Reduction();
  return *this;
}

Rational Rational::operator++(int) {
  auto other = *this;
  numerator_ += denominator_;
  Reduction();
  return other;
}

Rational &Rational::operator--() {
  numerator_ -= denominator_;
  Reduction();
  return *this;
}

Rational Rational::operator--(int) {
  auto other = *this;
  numerator_ -= denominator_;
  Reduction();
  return other;
}

bool operator<(const Rational &left, const Rational &other) {
  auto result = left - other;
  return result.numerator_ < 0;
}

bool operator>=(const Rational &left, const Rational &other) {
  auto result = left - other;
  return result.numerator_ >= 0;
}

bool operator==(const Rational &left, const Rational &other) {
  auto result = left - other;
  return result.numerator_ == 0;
}

bool operator>(const Rational &left, const Rational &other) {
  auto result = left - other;
  return result.numerator_ > 0;
}

bool operator<=(const Rational &left, const Rational &other) {
  auto result = left - other;
  return result.numerator_ <= 0;
}

bool operator!=(const Rational &left, const Rational &other) {
  auto result = left - other;
  return result.numerator_ != 0;
}

Rational Rational::operator-() const {
  auto copy = *this;
  copy.numerator_ = -numerator_;
  return copy;
}

Rational Rational::operator+() const {
  return *this;
}