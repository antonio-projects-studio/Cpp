#ifndef UNORDERED_SET_UNORDERED_SET_H
#define UNORDERED_SET_UNORDERED_SET_H
#define ITERATOR_IMPLEMENTED
#define FORWARD_LIST_IMPLEMENTED

#include <iostream>
#include <memory>
#include <iterator>
#include <stdexcept>
#include <exception>
#include <vector>
#include <forward_list>
#include <functional>

template <class Key>
class Iter {
 public:
  bool flag_{false};
  typename std::forward_list<Key>::const_iterator iterator_;

 public:
  explicit Iter() : flag_(false){};

  explicit Iter(typename std::forward_list<Key>::const_iterator iter) : flag_(true), iterator_(iter) {
  }
};

template <class Key, class Hash = std::hash<Key>, class KeyEqual = std::equal_to<Key>>
class UnorderedSet {
 private:
  std::vector<Iter<Key>> set_{};
  std::forward_list<Key> list_of_elements_{};
  size_t n_bucket_{};
  size_t n_elements_{};
  float load_factor_{};
  using ItInVec = Iter<Key>;

 public:
  template <class>
  friend class Iter;

 public:
  using ValueType = Key;
  using SizeType = size_t;
  using Hasher = Hash;
  using Iterator = typename std::forward_list<ValueType>::const_iterator;
  using ConstIterator = typename std::forward_list<ValueType>::const_iterator;
  using DifferenceType = typename std::forward_list<ValueType>::difference_type;

 public:
  UnorderedSet() = default;

  explicit UnorderedSet(size_t count) : n_bucket_(count) {
    set_.resize(count);
  }

  template <class Iter, class = std::enable_if_t<std::is_base_of_v<
                            std::forward_iterator_tag, typename std::iterator_traits<Iter>::iterator_category>>>
  UnorderedSet(Iter first, Iter second) : n_bucket_(std::distance(first, second)) {
    set_.resize(std::distance(first, second));
    for (auto iter = first; iter != second; ++iter) {
      HashAndPushIfElementIsNotInSet(*iter);
    }
    MakeLoadFactor();
  }

  UnorderedSet(const UnorderedSet &other) {
    n_bucket_ = other.n_bucket_;
    load_factor_ = other.load_factor_;
    set_.resize(n_bucket_);
    if (n_bucket_ == 0) {
      n_elements_ = 0;
      return;
    }
    for (auto &item : other.list_of_elements_) {
      HashAndPush(item);
    }
  }

  UnorderedSet(UnorderedSet &&other) noexcept {
    size_t idx = 0;
    if (other.n_elements_ != 0) {
      auto value = *other.begin();
      idx = other.HashValue(value);
    }
    n_bucket_ = std::exchange(other.n_bucket_, 0);
    n_elements_ = std::exchange(other.n_elements_, 0);
    load_factor_ = std::exchange(other.load_factor_, 0);
    set_ = std::move(other.set_);
    list_of_elements_ = std::move(other.list_of_elements_);
    if (n_elements_ != 0) {
      set_[idx] = ItInVec(list_of_elements_.cbefore_begin());
    }
  };

  UnorderedSet &operator=(const UnorderedSet &other) {
    if (this != &other) {
      n_elements_ = 0;
      n_bucket_ = other.n_bucket_;
      load_factor_ = other.load_factor_;
      set_.resize(other.set_.size());
      if (n_bucket_ == 0) {
        n_elements_ = 0;
        return *this;
      }
      for (auto &item : other.list_of_elements_) {
        HashAndPush(item);
      }
    }
    return *this;
  };

  UnorderedSet &operator=(UnorderedSet &&other) noexcept {
    if (this != &other) {
      size_t idx = 0;
      if (other.n_elements_ != 0) {
        auto value = *other.begin();
        idx = other.HashValue(value);
      }
      n_bucket_ = std::exchange(other.n_bucket_, 0);
      n_elements_ = std::exchange(other.n_elements_, 0);
      load_factor_ = std::exchange(other.load_factor_, 0);
      set_ = std::move(other.set_);
      list_of_elements_ = std::move(other.list_of_elements_);
      if (n_elements_ != 0) {
        set_[idx] = ItInVec(list_of_elements_.before_begin());
      }
    }
    return *this;
  };

  ~UnorderedSet() noexcept = default;

  inline void MakeLoadFactor() {
    load_factor_ = static_cast<float>(n_elements_) / n_bucket_;
  }

  size_t HashValue(const ValueType &value) const {
    return Hasher{}(value) % n_bucket_;
  }

  bool CheckHash(const ValueType &value_1, const ValueType &value_2) const {
    return HashValue(value_1) == HashValue(value_2);
  }

  std::pair<Iterator, bool> CheckIfElementInSetWithIterator(const size_t idx, const ValueType &value) {
    if (set_[idx].flag_) {
      auto iter = set_[idx].iterator_;
      ++iter;
      auto iter_end = list_of_elements_.end();
      for (; iter != iter_end; ++iter) {
        if (!CheckHash(*iter, value)) {
          return std::make_pair(iter, true);
        }
        if (*iter == value) {
          return std::make_pair(iter, false);
        }
      }
    }
    return std::make_pair(list_of_elements_.end(), true);
  }

  bool CheckIfElementInSet(const size_t idx, const ValueType &value) const {
    if (idx >= n_bucket_) {
      return false;
    }
    auto iter = list_of_elements_.begin();
    if (set_[idx].flag_) {
      if (list_of_elements_.before_begin() != set_[idx].iterator_) {
        iter = set_[idx].iterator_;
        ++iter;
      }
      auto iter_end = list_of_elements_.end();
      for (; iter != iter_end; ++iter) {
        if (CheckHash(*iter, value)) {
          if (*iter == value) {
            return true;
          }
          continue;
        }
        return false;
      }
    }
    return false;
  }

  std::pair<Iterator, bool> HashAndPushWithIterator(const ValueType &value) {
    auto idx = HashValue(value);
    if (!set_[idx].flag_) {
      list_of_elements_.push_front(value);
      auto begin = list_of_elements_.begin();
      auto begin_copy = list_of_elements_.begin();
      set_[idx] = ItInVec(list_of_elements_.before_begin());
      if (++begin != list_of_elements_.end()) {
        auto idx2 = HashValue(*begin);
        set_[idx2] = ItInVec(begin_copy);
      }
      ++n_elements_;
      MakeLoadFactor();
      return std::make_pair(begin_copy, true);
    }
    list_of_elements_.emplace_after(set_[idx].iterator_, value);
    ++n_elements_;
    MakeLoadFactor();
    auto iter = set_[idx].iterator_;
    return std::make_pair(++iter, true);
  }

  void HashAndPush(const ValueType &value) {
    auto idx = HashValue(value);
    if (!set_[idx].flag_) {
      list_of_elements_.push_front(value);
      set_[idx] = ItInVec(list_of_elements_.before_begin());
      auto begin = list_of_elements_.begin();
      auto begin_copy = list_of_elements_.begin();
      if (++begin != list_of_elements_.end()) {
        auto idx2 = HashValue(*begin);
        set_[idx2] = ItInVec(begin_copy);
      }
      ++n_elements_;
      return;
    }
    list_of_elements_.emplace_after(set_[idx].iterator_, value);
    ++n_elements_;
  }

  bool HashAndPushIfElementIsNotInSet(const ValueType &value) {
    auto idx = HashValue(value);
    if (CheckIfElementInSet(idx, value)) {
      return false;
    }
    HashAndPush(value);
    return true;
  }

  bool CheckLoadFactor() {
    return load_factor_ < 1;
  }

  [[nodiscard]] SizeType Size() const noexcept {
    return n_elements_;
  }

  [[nodiscard]] bool Empty() const noexcept {
    return n_elements_ == 0;
  }

  Iterator end() {  // NOLINT
    return list_of_elements_.end();
  }

  Iterator begin() {  // NOLINT
    return list_of_elements_.begin();
  }

  ConstIterator end() const {  // NOLINT
    return list_of_elements_.end();
  }

  ConstIterator begin() const {  // NOLINT
    return list_of_elements_.begin();
  }

  ConstIterator cend() const {  // NOLINT
    return list_of_elements_.cend();
  }

  ConstIterator cbegin() const {  // NOLINT
    return list_of_elements_.cbegin();
  }

  void Clear() {
    set_.clear();
    set_.resize(n_bucket_);
    list_of_elements_.clear();
    n_elements_ = 0;
    load_factor_ = 0;
  }

  void Rehash(size_t new_bucket_count) {
    if (new_bucket_count < n_elements_ || new_bucket_count == n_bucket_) {
      return;
    }
    auto copy_list = std::move(list_of_elements_);
    auto copy_bucket = n_bucket_;
    std::vector<Iter<Key>> copy_set(new_bucket_count);
    n_elements_ = 0;
    load_factor_ = 0;
    set_.swap(copy_set);
    n_bucket_ = new_bucket_count;
    if (copy_bucket == 0) {
      return;
    }
    for (auto &item : copy_list) {
      HashAndPush(item);
    }
    MakeLoadFactor();
  }

  [[nodiscard]] bool Find(const ValueType &value) const {
    if (n_elements_ == 0) {
      return false;
    }
    auto idx = HashValue(value);
    return CheckIfElementInSet(idx, value);
  }

  std::pair<Iterator, bool> Insert(const ValueType &insert_value) {
    if (n_bucket_ == 0) {
      ++n_bucket_;
      set_.resize(1);
      return HashAndPushWithIterator(insert_value);
    }
    std::pair<Iterator, bool> pair = CheckIfElementInSetWithIterator(HashValue(insert_value), insert_value);
    if (!pair.second) {
      return pair;
    }
    if (CheckLoadFactor()) {
      return HashAndPushWithIterator(insert_value);
    }
    Rehash(2 * n_bucket_);
    return HashAndPushWithIterator(insert_value);
  }

  std::pair<Iterator, bool> Insert(ValueType &&insert_value) {
    ValueType copy_insert_value = std::move(insert_value);
    return Insert(copy_insert_value);
  }

  size_t Erase(const ValueType &erase_value) {
    std::pair<Iterator, bool> pair = CheckIfElementInSetWithIterator(HashValue(erase_value), erase_value);
    if (pair.second) {
      return 0;
    }
    auto idx = HashValue(erase_value);
    auto iter = set_[idx].iterator_;
    auto distance = std::distance(iter, pair.first);
    std::advance(iter, --distance);
    auto copy_iter = pair.first;
    if (++copy_iter != list_of_elements_.end()) {
      if (!CheckHash(*copy_iter, *pair.first)) {
        if (iter == set_[idx].iterator_) {
          set_[idx] = ItInVec();
        }
        auto idx2 = HashValue(*copy_iter);
        set_[idx2] = ItInVec(iter);
      } else {
        if (iter == set_[idx].iterator_) {
          auto idx2 = HashValue(*copy_iter);
          set_[idx2] = ItInVec(iter);
        }
      }
    } else {
      if (iter == set_[idx].iterator_) {
        set_[idx] = ItInVec();
      }
    }
    list_of_elements_.erase_after(iter);
    --n_elements_;
    MakeLoadFactor();
    return 1;
  }

  void Reserve(size_t new_bucket_count) {
    if (new_bucket_count > n_bucket_) {
      Rehash(new_bucket_count);
    }
  }

  [[nodiscard]] SizeType BucketCount() const {
    return n_bucket_;
  }

  [[nodiscard]] size_t BucketSize(size_t id) const {
    if (id >= n_bucket_) {
      return 0;
    }
    if (set_[id].flag_) {
      auto iter = set_[id].iterator_;
      auto iter_next = set_[id].iterator_;
      ++iter_next;
      while (++iter, ++iter_next != list_of_elements_.end()) {
        if (!CheckHash(*(iter), *(iter_next))) {
          break;
        }
      }
      return std::distance(set_[id].iterator_, iter);
    }
    return 0;
  }

  [[nodiscard]] size_t Bucket(ValueType value) const {
    return HashValue(value);
  }

  [[nodiscard]] float LoadFactor() const {
    return load_factor_;
  }
};

#endif  // UNORDERED_SET_UNORDERED_SET_H