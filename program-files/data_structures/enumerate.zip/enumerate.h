#pragma once

#include <utility>
#include <cstdint>

template <class Container>
class EnumeratorLValueHolder {
 private:
  Container &container_;

 public:
  explicit EnumeratorLValueHolder(Container &container) : container_(container) {
  }

  using iterator = decltype(std::declval<Container>().begin());  // NOLINT
  using T = decltype(*std::declval<iterator>());

  class Iterator {
   private:
    int64_t idx_;
    iterator iterator_;

   public:
    Iterator(int64_t idx, iterator iter) : idx_(idx), iterator_(iter){};

    std::pair<int64_t, T> operator*() {
      return {idx_, *iterator_};
    };

    Iterator &operator++() {
      ++idx_;
      ++iterator_;
      return *this;
    };

    bool operator!=(const Iterator &other) {
      return other.iterator_ != iterator_;
    };
  };

  Iterator begin() const {  // NOLINT
    return {0, container_.begin()};
  }

  Iterator end() const {  // NOLINT
    return {std::distance(container_.begin(), container_.end()), container_.end()};
  }
};

template <class Container>
auto Enumerate(Container &&container) {
  return EnumeratorLValueHolder<decltype(container)>(container);
}