#pragma once

#include <iostream>

class Iterator {
 private:
  int64_t idx_;
  int64_t step_;

 public:
  Iterator(int64_t idx, int64_t step) : idx_(idx), step_(step){};

  bool operator!=(const Iterator &other) {
    if (step_ > 0) {
      return idx_ < other.idx_;
    }
    return idx_ > other.idx_;
  }

  Iterator &operator++() {
    idx_ += step_;
    return *this;
  }

  Iterator operator++(int) {
    Iterator copy = *this;
    ++*this;
    return copy;
  }

  int64_t operator*() {
    return idx_;
  }
};

class Range {
 private:
  int64_t end_;
  int64_t begin_;
  int64_t step_;

 public:
  Range() = delete;

  explicit Range(int64_t end) : end_(end), begin_(0), step_(1) {
    if (end_ < 0) {
      end_ = 0;
    }
  }

  Range(int64_t begin, int64_t end) : end_(end), begin_(begin), step_(1) {
    if (end_ < begin_) {
      begin_ = 0;
      end_ = 0;
    }
  }

  Range(int64_t begin, int64_t end, int64_t step) : end_(end), begin_(begin), step_(step) {
    if (end_ < begin_ && step_ >= 0) {
      begin_ = 0;
      end_ = 0;
      return;
    }
    if (end_ > begin_ && step_ < 0) {
      begin_ = 0;
      end_ = 0;
      return;
    }
  }

  Iterator begin() const {  // NOLINT
    return {begin_, step_};
  }

  Iterator end() const {  // NOLINT
    return {end_, step_};
  }
};