#ifndef GEOMETRY_RAY_H
#define GEOMETRY_RAY_H

#include "IShape.h"
#include "point.h"
#include "segment.h"

namespace geometry {

class Ray : public IShape {
 public:
  Point a_, b_;

  Ray(Point a, Point b) : a_(a), b_(b){};

  Ray &Move(const Vector &vector) override;

  bool ContainsPoint(const Point &point) const override;

  bool CrossesSegment(const Segment &segment) const override;

  Ray *Clone() const override;

  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY_RAY_H