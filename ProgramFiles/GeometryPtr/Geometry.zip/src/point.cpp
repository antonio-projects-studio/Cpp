#include "../point.h"

#include <iomanip>
#include <sstream>

#include "../segment.h"

namespace geometry {
Point &Point::Move(const Vector &vector) {
  x += vector.x;
  y += vector.y;
  return *this;
}

bool Point::ContainsPoint(const Point &point) const {
  return (*this) == point;
}

bool Point::CrossesSegment(const Segment &segment) const {
  return segment.ContainsPoint(*this);
}

Point *Point::Clone() const {
  return new Point(*this);
}

std::string Point::ToString() const {
  std::stringstream ss;
  ss << "Point(";
  ss << x;
  ss << ", ";
  ss << y;
  ss << ")";
  return ss.str();
}

Vector Point::operator-(const Point &p) const {
  Vector res = {x - p.x, y - p.y};
  return res;
}

bool operator==(const Point &left, const Point &right) {
  return left.x == right.x && left.y == right.y;
}

Point &Point::operator+=(const Vector &vector) {
  x += vector.x;
  y += vector.y;
  return *this;
}

}  // namespace geometry