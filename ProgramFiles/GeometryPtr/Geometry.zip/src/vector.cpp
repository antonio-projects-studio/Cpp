#include "../vector.h"

#include <iomanip>

#include "../vector.h"

namespace geometry {

Vector operator+(const Vector &left, const Vector &right) {
  return {left.x + right.x, left.y + right.y};
}

Vector operator-(const Vector &left, const Vector &right) {
  return {left.x - right.x, left.y - right.y};
}

Vector operator*(const Vector &left, const int cnt) {
  return {left.x * cnt, left.y * cnt};
}

Vector operator/(const Vector &left, const int cnt) {
  return {left.x / cnt, left.y / cnt};
}

Vector &Vector::operator+=(const Vector &other) {
  x += other.x;
  y += other.y;
  return *this;
}

Vector &Vector::operator-=(const Vector &other) {
  x -= other.x;
  y -= other.y;
  return *this;
}

bool Vector::operator==(const Vector &other) {
  return this->x == other.x && this->y == other.y;
}

bool Vector::operator==(const Vector &other) const {
  return this->x == other.x && this->y == other.y;
}

std::ostream &operator<<(std::ostream &os, const Vector &vector) {
  os << std::fixed;
  os << '(' << vector.x << ", " << vector.y << ')';
  return os;
}

int64_t VectorProduct(const Vector &left, const Vector &right) {
  auto res_1 = left.x * right.y;
  auto res_2 = left.y * right.x;
  auto res = res_1 - res_2;
  return res;
}

int64_t ScaleProduct(const Vector &left, const Vector &right) {
  auto res_1 = left.x * right.x;
  auto res_2 = left.y * right.y;
  auto res = res_1 + res_2;
  return res;
}

int64_t Mod(const Vector &vector) {
  auto xx = vector.x * vector.x;
  auto yy = vector.y * vector.y;
  auto res = xx + yy;
  return res;
}

}  // namespace geometry
