#include "../line.h"

#include <sstream>

namespace geometry {
Line &Line::Move(const Vector &vector) {
  a_ += vector;
  b_ += vector;
  return *this;
}

bool Line::ContainsPoint(const Point &point) const {
  int64_t vp = VectorProduct(b_ - a_, point - a_);
  return vp == 0;
}

bool Line::CrossesSegment(const Segment &segment) const {
  if (segment.a_ == segment.b_) {
    return ContainsPoint(segment.a_);
  }

  if (ContainsPoint(segment.a_) || ContainsPoint(segment.b_)) {
    return true;
  }

  int64_t t1 = VectorProduct(b_ - a_, segment.a_ - a_);
  int64_t t2 = VectorProduct(b_ - a_, segment.b_ - a_);

  if (t1 == 0 && t2 == 0) {
    return true;
  }
  if (t1 > 0 && t2 > 0) {
    return false;
  }
  if (t1 < 0 && t2 < 0) {
    return false;
  }
  return true;
}

Line *Line::Clone() const {
  return new Line(*this);
}

std::string Line::ToString() const {
  auto a = b_.y - a_.y;
  auto b = a_.x - b_.x;
  auto c = -a * a_.x - b * a_.y;

  std::stringstream ss;
  ss << "Line(" << a << ", " << b << ", " << c << ")";
  return ss.str();
}
}  // namespace geometry