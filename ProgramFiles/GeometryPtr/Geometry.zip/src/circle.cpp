#include "../circle.h"

#include <sstream>

namespace geometry {
Circle &Circle::Move(const Vector &vector) {
  a_ += vector;
  return *this;
}

bool Circle::ContainsPoint(const Point &point) const {
  int64_t mod = Mod(point - a_);
  int64_t rr = static_cast<int64_t>(radius_);
  return mod <= rr * rr;
}

bool Circle::CrossesSegment(const Segment &segment) const {
  auto rad = radius_;
  auto radius = rad * rad;

  int64_t ra = Mod(segment.a_ - a_);
  int64_t rb = Mod(segment.b_ - a_);

  if (ra == radius || rb == radius) {
    return true;
  }

  if (ra < radius && rb < radius) {
    return false;
  }
  bool ca = ContainsPoint(segment.a_);
  bool cb = ContainsPoint(segment.b_);

  if ((ca && !cb) || (cb && !ca)) {
    return true;
  }

  int64_t mod = Mod(segment.b_ - segment.a_);
  int64_t vp = VectorProduct(segment.b_ - segment.a_, a_ - segment.a_);
  if (vp * vp > mod * radius_ * radius_) {
    return false;
  }

  Vector va = segment.a_ - a_;
  Vector vb = segment.a_ - a_;
  return va == vb;
}

Circle *Circle::Clone() const {
  //
  return new Circle(*this);
}

std::string Circle::ToString() const {
  std::stringstream ss;
  ss << "Circle(" << a_.ToString() << ", " << radius_ << ")";
  return ss.str();
}

}  // namespace geometry
