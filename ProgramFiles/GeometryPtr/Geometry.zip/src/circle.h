#pragma once

#include "IShape.h"
#include "point.h"
#include "segment.h"

namespace geometry {

class Circle : public IShape {

 public:
  Point A;
  int R;

  Circle(Point a, int r);

  Circle &Move(const Vector &v) override;

  bool ContainsPoint(const Point &p) const override;

  bool CrossesSegment(const Segment &a) const override;

  Circle *Clone() const override;

  std::string ToString() const override;
};
}  // namespace geometry