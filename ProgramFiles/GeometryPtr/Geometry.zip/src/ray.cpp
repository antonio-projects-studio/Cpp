#include "../ray.h"

#include <sstream>

namespace geometry {
Ray &Ray::Move(const Vector &vector) {
  a_ += vector;
  b_ += vector;
  return *this;
}

bool Ray::ContainsPoint(const Point &point) const {
  int64_t sp = ScaleProduct(b_ - a_, point - a_);
  int64_t vp = VectorProduct(b_ - a_, point - a_);
  return vp == 0 && sp >= 0;
}

bool Ray::CrossesSegment(const Segment &segment) const {
  if (segment.a_ == segment.b_) {
    return ContainsPoint(segment.a_);
  }

  if (ContainsPoint(segment.a_) || ContainsPoint(segment.b_)) {
    return true;
  }

  if (segment.ContainsPoint(a_)) {
    return true;
  }

  int64_t t1 = VectorProduct(segment.a_ - a_, b_ - a_);
  int64_t t2 = VectorProduct(segment.b_ - a_, b_ - a_);

  if (t1 < 0 && t2 < 0) {
    return false;
  }
  if (t1 > 0 && t2 > 0) {
    return false;
  }

  t1 = VectorProduct(a_ - segment.a_, segment.b_ - segment.a_);
  t2 = VectorProduct(b_ - a_, segment.b_ - segment.a_);

  if (t1 < 0 && t2 > 0) {
    return true;
  }
  if (t1 > 0 && t2 < 0) {
    return true;
  }

  return false;
}

Ray *Ray::Clone() const {
  //
  return new Ray(*this);
}

std::string Ray::ToString() const {
  std::stringstream ss;
  ss << "Ray(";
  ss << a_.ToString();
  ss << ", Vector";
  ss << b_ - a_;
  ss << ")";
  return ss.str();
}

}  // namespace geometry
