#include "../polygon.h"

#include <sstream>

#include "../ray.h"

namespace geometry {
Polygon &Polygon::Move(const Vector &vector) {
  for (Point &point : points_) {
    point.Move(vector);
  }
  return *this;
}

bool Polygon::ContainsPoint(const Point &point) const {
  Ray r = {point, {point.x + 10000, point.y + 1}};

  size_t count = 0;

  for (size_t i = 0; i < points_.size() - 1; i++) {
    Point a = points_[i];
    Point b = points_[i + 1];
    Segment s = {a, b};
    if (s.ContainsPoint(point)) {
      return true;
    }
    if (!r.ContainsPoint(a) && r.CrossesSegment(s)) {
      count++;
    }
  }

  Point a = points_.back();
  Point b = points_[0];
  Segment s = {a, b};
  if (s.ContainsPoint(point)) {
    return true;
  }
  if (!r.ContainsPoint(a) && r.CrossesSegment({a, b})) {
    count++;
  }

  return count % 2 == 1;
}

bool Polygon::CrossesSegment(const Segment &segment) const {
  for (size_t i = 0; i < points_.size() - 1; i++) {
    Segment s = {points_[i], points_[i + 1]};
    if (s.CrossesSegment(segment)) {
      return true;
    }
  }
  Segment s = {points_.back(), points_[0]};
  if (s.CrossesSegment(segment)) {
    return true;
  }
  return false;
}

Polygon *Polygon::Clone() const {
  //
  return new Polygon(*this);
}

std::string Polygon::ToString() const {
  std::stringstream ss;
  ss << "Polygon(";
  for (size_t i = 0; i < points_.size(); i++) {
    ss << points_[i].ToString();
    if (i < points_.size() - 1) {
      ss << ", ";
    }
  }
  ss << ")";
  return ss.str();
}

}  // namespace geometry