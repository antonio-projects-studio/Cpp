#include "../segment.h"

#include <sstream>

namespace geometry {
Segment &Segment::Move(const Vector &vector) {
  a_ += vector;
  b_ += vector;
  return *this;
}

bool Segment::ContainsPoint(const Point &point) const {
  if (a_ == b_) {
    return a_ == point;
  }
  if (a_ == point || b_ == point) {
    return true;
  }
  int64_t sp = ScaleProduct(b_ - a_, point - a_);
  int64_t vp = VectorProduct(b_ - a_, point - a_);
  return vp == 0 && sp >= 0 && sp <= Mod(b_ - a_);
}

bool Segment::CrossesSegment(const Segment &segment) const {
  if (a_ == b_) {
    return segment.ContainsPoint(a_);
  }

  if (segment.a_ == segment.b_) {
    return this->ContainsPoint(segment.a_);
  }

  int64_t t1 = VectorProduct(b_ - a_, segment.a_ - a_);
  int64_t t2 = VectorProduct(b_ - a_, segment.b_ - a_);

  if (t1 == 0 && t2 == 0) {
    return ContainsPoint(segment.a_) || ContainsPoint(segment.b_);
  }

  if ((t1 > 0 && t2 > 0) || (t1 < 0 && t2 < 0)) {
    return false;
  }

  t1 = VectorProduct(segment.b_ - segment.a_, a_ - segment.a_);
  t2 = VectorProduct(segment.b_ - segment.a_, b_ - segment.a_);

  if ((t1 > 0 && t2 > 0) || (t1 < 0 && t2 < 0)) {
    return false;
  }

  return true;
}

Segment *Segment::Clone() const {
  return new Segment(*this);
}

std::string Segment::ToString() const {
  std::stringstream ss;
  ss << "Segment(";
  ss << a_.ToString();
  ss << ", ";
  ss << b_.ToString();
  ss << ")";
  return ss.str();
}

}  // namespace geometry