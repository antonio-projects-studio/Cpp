#ifndef GEOMETRY_CIRCLE_H
#define GEOMETRY_CIRCLE_H

#include "IShape.h"
#include "point.h"
#include "segment.h"

namespace geometry {

class Circle : public IShape {

 public:
  Point a_;
  int64_t radius_;

  Circle(Point a, int r) : a_(a), radius_(r){};

  Circle &Move(const Vector &v) override;

  bool ContainsPoint(const Point &p) const override;

  bool CrossesSegment(const Segment &a) const override;

  Circle *Clone() const override;

  std::string ToString() const override;
};
}  // namespace geometry

#endif  // GEOMETRY_CIRCLE_H