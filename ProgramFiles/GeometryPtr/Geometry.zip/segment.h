#ifndef GEOMETRY_SEGMENT_H
#define GEOMETRY_SEGMENT_H

#include "IShape.h"
#include "point.h"

namespace geometry {
class Segment : public IShape {
 public:
  Point a_, b_;

  Segment(const Point &a, const Point &b) : a_(a), b_(b){};

  Segment &Move(const Vector &vector) override;

  bool ContainsPoint(const Point &point) const override;

  bool CrossesSegment(const Segment &segment) const override;

  Segment *Clone() const override;

  std::string ToString() const override;
};
}  // namespace geometry
#endif  // GEOMETRY_SEGMENT_H