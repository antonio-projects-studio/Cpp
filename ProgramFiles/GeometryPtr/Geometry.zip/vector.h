#ifndef GEOMETRY_VECTOR_H
#define GEOMETRY_VECTOR_H

#include <iostream>

namespace geometry {
class Vector {
 public:
  int64_t x;
  int64_t y;

  Vector(int64_t x, int64_t y) : x(x), y(y){};

  inline Vector operator+() const {
    return *this;
  };

  inline Vector operator-() const {
    return {-this->x, -this->y};
  };

  Vector &operator+=(const Vector &other);

  Vector &operator-=(const Vector &other);

  bool operator==(const Vector &other);

  bool operator==(const Vector &other) const;

  friend std::ostream &operator<<(std::ostream &os, const Vector &vector);
};

Vector operator+(const Vector &left, const Vector &right);

Vector operator-(const Vector &left, const Vector &right);

Vector operator*(const Vector &left, const int cnt);

Vector operator/(const Vector &left, const int cnt);

int64_t VectorProduct(const Vector &left, const Vector &right);

int64_t ScaleProduct(const Vector &left, const Vector &right);

int64_t Mod(const Vector &vector);
}  // namespace geometry

#endif  // GEOMETRY_VECTOR_H