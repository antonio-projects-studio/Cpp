#ifndef GEOMETRY_POLYGON_H
#define GEOMETRY_POLYGON_H

#include "IShape.h"
#include "point.h"
#include "segment.h"
#include "vector"

namespace geometry {

class Polygon : public IShape {
 public:
  std::vector<Point> points_;

  explicit Polygon(std::vector<Point> points) : points_(points){};

  Polygon &Move(const Vector &vector) override;

  bool ContainsPoint(const Point &point) const override;

  bool CrossesSegment(const Segment &segment) const override;

  Polygon *Clone() const override;

  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY_POLYGON_H