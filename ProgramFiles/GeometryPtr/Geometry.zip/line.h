#ifndef GEOMETRY_LINE_H
#define GEOMETRY_LINE_H

#include "IShape.h"
#include "segment.h"

namespace geometry {

class Line : public IShape {
 public:
  Point a_, b_;

  Line(Point a, Point b) : a_(a), b_(b){};

  Line &Move(const Vector &vector) override;

  bool ContainsPoint(const Point &point) const override;

  bool CrossesSegment(const Segment &segment) const override;

  Line *Clone() const override;

  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY_LINE_H