#ifndef GEOMETRY_POINT_H
#define GEOMETRY_POINT_H

#include "IShape.h"

namespace geometry {

class Point : public IShape {
 public:
  int64_t x, y;

  Point(int64_t x, int64_t y) : x(x), y(y){};

  Point &Move(const Vector &vector) override;

  bool ContainsPoint(const Point &point) const override;

  bool CrossesSegment(const Segment &segment) const override;

  Point *Clone() const override;

  std::string ToString() const override;

  Point &operator+=(const Vector &vector);

  Vector operator-(const Point &p) const;
};

bool operator==(const Point &left, const Point &right);
}  // namespace geometry

#endif  // GEOMETRY_POINT_H