#ifndef UNIQUE_PTR_UNIQUE_PTR_H
#define UNIQUE_PTR_UNIQUE_PTR_H

template <class T, class Deleter = std::default_delete<T>>
class UniquePtr {
  T *ptr_ = nullptr;

 public:
  UniquePtr() : ptr_(nullptr){};

  explicit UniquePtr(T *ptr) : ptr_(ptr){};

  UniquePtr(const UniquePtr &other) = delete;

  UniquePtr &operator=(const UniquePtr &other) = delete;

  UniquePtr(UniquePtr &&other) noexcept : ptr_(other.ptr_) {
    other.ptr_ = nullptr;
  }

  UniquePtr &operator=(UniquePtr &&other) noexcept {
    if (this != &other) {
      Deleter deleter;
      deleter(ptr_);
      ptr_ = other.ptr_;
      other.ptr_ = nullptr;
    }
    return *this;
  };

  T *Get() const noexcept {
    return ptr_;
  }

  void Swap(UniquePtr &other) {
    T *copy = ptr_;
    ptr_ = other.ptr_;
    other.ptr_ = copy;
  }

  T &operator*() const {
    return *ptr_;
  }

  T *operator->() const {
    return ptr_;
  }

  T *Release() {
    T *copy = ptr_;
    ptr_ = nullptr;
    return copy;
  }

  void Reset(T *ptr = nullptr) {
    Deleter deleter;
    deleter(ptr_);
    ptr_ = ptr;
  }

  explicit operator bool() const {
    return ptr_ != nullptr;
  }

  ~UniquePtr() {
    Deleter deleter;
    deleter(ptr_);
  }
};

#endif  // UNIQUE_PTR_UNIQUE_PTR_H
