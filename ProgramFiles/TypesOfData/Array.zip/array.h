#define ARRAY_TRAITS_IMPLEMENTED
#pragma once

#include <iostream>
#include <stdexcept>

class ArrayOutOfRange : public std::out_of_range {
 public:
  ArrayOutOfRange() : std::out_of_range("ArrayOutOfRange") {
  }
};

template <typename T, size_t N>
class Array {
 public:
  T arr_[N]{};

  Array() = default;

  inline const T &operator[](size_t idx) const {
    return arr_[idx];
  }

  inline T &operator[](size_t idx) {
    return const_cast<T &>(const_cast<const Array<T, N> &>(*this)[idx]);
  }

  T &Front() {
    return arr_[0];
  }

  const T &Front() const {
    return arr_[0];
  }

  T &Back() {
    return arr_[N - 1];
  }

  T const &Back() const {
    return arr_[N - 1];
  }

  T *Data() {
    return arr_;
  }

  T const *Data() const {
    return arr_;
  }

  void Fill(const T &value) {
    for (auto &item : arr_) {
      item = value;
    }
  }

  inline const T &At(int64_t idx) const {
    int64_t size = N;
    if (idx >= size || idx < 0) {
      throw ArrayOutOfRange{};
    }
    return arr_[idx];
  }

  inline T &At(int64_t idx) {
    return const_cast<T &>(const_cast<const Array<T, N> &>(*this).At(idx));
  }

  void Swap(Array<T, N> &other) {
    for (size_t i = 0; i < N; ++i) {
      std::swap(arr_[i], other.arr_[i]);
    }
  }

  bool Empty() const {
    return N == 0;
  }

  T Size() const {
    return N;
  }
};

template <class T, auto N>
auto GetSize(T (&)[N]) {
  return N;
}

template <class T>
auto GetSize(T) {
  return 0;
}

template <class T>
int GetRank(T) {
  return 0;
}

template <class T>
int GetRank(T *arr) {
  return GetRank(*arr) + 1;
}

template <class T>
int GetNumElements(T) {
  return 1;
}

template <class T, int N>
int GetNumElements(T (&arr)[N]) {
  return N * GetNumElements(*arr);
}